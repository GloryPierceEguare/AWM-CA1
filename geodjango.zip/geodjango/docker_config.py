#POSTGIS_PORT = 25432
PROJECT_NAME = 'geodjango'
#DEPLOY_SECURE = False

DEPLOY_SECURE = True
SECRET_KEY = 'i068fpynq#3ep7_v@#(+yjqcm(dk7cvs(f(hx*a#5##fy-!p^i'